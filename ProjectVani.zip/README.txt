Project Vani - Sign Language Detection
Embeetek Technologies

Requirements:
- Miniconda or Anaconda installed
- ESP32-CAM on network as asl.local

Setup:
1. Run setup.bat (only first time)
2. Run run.bat to start

Web Interface:
Open browser at http://localhost:5000