@echo off
echo ========================================
echo  Project Vani - Embeetek Technologies
echo  Auto Setup Script
echo ========================================

echo Creating conda environment...
conda create -n gesture_env python=3.9 -y

echo Activating environment...
call conda activate gesture_env

echo Installing dependencies...
pip install -r requirements.txt

echo ========================================
echo  Setup Complete!
echo  Run the project using:
echo  run.bat
echo ========================================
pause