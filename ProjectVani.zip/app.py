#!/usr/bin/env python
# -*- coding: utf-8 -*-
# =============================================================================
# Hand Gesture / Sign Language Recognition
# Embeetek Technologies
# ESP32-CAM stream + MediaPipe geometry detection + MQTT + Flask web stream
# =============================================================================
from flask import Flask, Response
import threading
import paho.mqtt.client as mqtt
import json
import copy
import argparse
from collections import deque

import cv2 as cv
import numpy as np
import mediapipe as mp

from utils import CvFpsCalc

app = Flask(__name__)
output_frame = None
frame_lock = threading.Lock()

# Adafruit IO credentials
AIO_USERNAME = "ASL_INTR01"
AIO_KEY = "aio_QzzG55AAz1tNKSR2RxfE5rnAXypV"
AIO_FEED = "predictions"
TOPIC = f"{AIO_USERNAME}/feeds/{AIO_FEED}"

# MQTT — wrapped in try so app doesn't crash if no internet
mqtt_client = mqtt.Client()
mqtt_client.username_pw_set(AIO_USERNAME, AIO_KEY)
try:
    mqtt_client.connect("io.adafruit.com", 1883, 60)
    mqtt_client.loop_start()
    print("[MQTT] Connected to Adafruit IO")
except Exception as e:
    print(f"[MQTT] Connection failed: {e} — continuing without MQTT")


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--stream_url", type=str, default=None,
                        help="ESP32-CAM stream e.g. http://asl.local:81/stream")
    parser.add_argument("--width", type=int, default=960)
    parser.add_argument("--height", type=int, default=540)
    parser.add_argument('--use_static_image_mode', action='store_true')
    parser.add_argument("--min_detection_confidence", type=float, default=0.7)
    parser.add_argument("--min_tracking_confidence", type=float, default=0.5)
    return parser.parse_args()


# ── Geometry-based gesture detection ─────────────────────────────────────────
def get_finger_states(landmarks):
    fingers = []
    thumb_tip = np.array([landmarks[4].x, landmarks[4].y])
    index_mcp = np.array([landmarks[5].x, landmarks[5].y])
    fingers.append(np.linalg.norm(thumb_tip - index_mcp) > 0.1)
    for tip, pip in zip([8, 12, 16, 20], [6, 10, 14, 18]):
        fingers.append(landmarks[tip].y < landmarks[pip].y)
    return fingers


def thumb_index_touching(landmarks):
    thumb = np.array([landmarks[4].x, landmarks[4].y])
    index = np.array([landmarks[8].x, landmarks[8].y])
    return np.linalg.norm(thumb - index) < 0.07


def classify_gesture(landmarks):
    t, i, m, r, p = get_finger_states(landmarks)
    if thumb_index_touching(landmarks) and m and r and p:
        return "Nice"
    if t and not i and not m and not r and not p:
        return "I Agree"
    if not t and i and m and not r and not p:
        return "Stay Calm"
    if not t and i and not m and not r and not p:
        return "I Have A Doubt"
    if not t and i and not m and not r and p:
        return "Can You Please Come Here"
    if not t and i and m and r and p:
        return "Help Me"
    if t and i and m and r and p:
        return "Hello"
    if not t and not i and not m and not r and not p:
        return "Its Dangerous!"
    return "Unknown"


# ── Flask stream ──────────────────────────────────────────────────────────────
def generate_frames():
    global output_frame
    while True:
        if output_frame is None:
            import time
            time.sleep(0.01)
            continue
        with frame_lock:
            _, buffer = cv.imencode('.jpg', output_frame,
                                    [cv.IMWRITE_JPEG_QUALITY, 75])
            frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')


@app.route('/video')
def video():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/')
def index():
    return '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Project Vani</title>
        <style>
            *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

            body {
                background: #f4f4f4;
                color: #1a1a1a;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                align-items: center;
                padding: 40px 20px 24px;
                gap: 20px;
            }

            header { text-align: center; }

            header h1 {
                font-size: 20px;
                font-weight: 600;
                letter-spacing: 6px;
                text-transform: uppercase;
                color: #111;
            }

            header p {
                margin-top: 6px;
                font-size: 11px;
                color: #999;
                letter-spacing: 1.5px;
                text-transform: uppercase;
            }

            .divider {
                width: 36px;
                height: 2px;
                background: #00c44f;
                margin: 10px auto 0;
                border-radius: 2px;
            }

            .video-wrapper {
                position: relative;
                border-radius: 10px;
                overflow: hidden;
                background: #e0e0e0;
                border: 1px solid #ddd;
                box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            }

            .video-wrapper img {
                display: block;
                width: 480px;
                max-width: 90vw;
                aspect-ratio: 4/3;
                object-fit: cover;
            }

            .live-pill {
                position: absolute;
                bottom: 10px;
                left: 10px;
                background: rgba(255,255,255,0.85);
                backdrop-filter: blur(6px);
                border: 1px solid #e0e0e0;
                border-radius: 20px;
                padding: 4px 12px;
                font-size: 10px;
                letter-spacing: 1.5px;
                color: #00a843;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .live-dot {
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #00c44f;
                animation: pulse 1.5s infinite;
            }

            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.3; }
            }

            .controls {
                display: flex;
                gap: 10px;
            }

            button {
                padding: 10px 28px;
                border-radius: 6px;
                border: none;
                font-size: 12px;
                font-weight: 500;
                letter-spacing: 1.5px;
                text-transform: uppercase;
                cursor: pointer;
                transition: opacity 0.2s;
            }

            button:hover { opacity: 0.8; }

            .btn-start { background: #00c44f; color: #fff; }
            .btn-stop  { background: #fff; color: #444; border: 1px solid #ddd; }

            .status-row {
                display: flex;
                gap: 20px;
            }

            .status-item {
                display: flex;
                align-items: center;
                gap: 7px;
                font-size: 11px;
                color: #999;
                letter-spacing: 1px;
                text-transform: uppercase;
            }

            .status-dot {
                width: 6px;
                height: 6px;
                border-radius: 50%;
                background: #00c44f;
            }

            .status-dot.off { background: #ccc; }

            .team-section { text-align: center; }

            .team-label {
                font-size: 9px;
                color: #bbb;
                letter-spacing: 2px;
                text-transform: uppercase;
                margin-bottom: 8px;
            }

            .team {
                display: flex;
                gap: 6px;
                flex-wrap: wrap;
                justify-content: center;
            }

            .team-name {
                font-size: 11px;
                color: #888;
                background: #fff;
                border: 1px solid #e8e8e8;
                border-radius: 20px;
                padding: 3px 12px;
            }

            footer {
                margin-top: auto;
                font-size: 9px;
                color: #ccc;
                letter-spacing: 1px;
            }

            footer a {
                color: #ccc;
                text-decoration: none;
            }

            footer a:hover { color: #999; }
        </style>
    </head>
    <body>

        <header>
            <h1>Project Vani</h1>
            <p>Real-time Sign Language Detection</p>
            <div class="divider"></div>
        </header>

        <div class="video-wrapper">
            <img id="videoFeed" src="/video" alt="Live Feed">
            <div class="live-pill" id="livePill">
                <div class="live-dot" id="liveDot"></div>
                <span id="liveText">LIVE</span>
            </div>
        </div>

        <div class="controls">
            <button class="btn-start" onclick="startStream()">Start</button>
            <button class="btn-stop"  onclick="stopStream()">Stop</button>
        </div>

        <div class="status-row">
            <div class="status-item">
                <div class="status-dot" id="camDot"></div>
                <span id="camLabel">Camera</span>
            </div>
            <div class="status-item">
                <div class="status-dot"></div>
                <span>MQTT</span>
            </div>
        </div>

        <div class="team-section">
            <p class="team-label">Developed By</p>
            <div class="team">
                <span class="team-name">Komal Rane</span>
                <span class="team-name">Sandesh Sawant</span>
                <span class="team-name">Akshata Dhiwar</span>
                <span class="team-name">Akhilesh Gujar</span>
            </div>
        </div>

        <footer>
            <a href="https://embeetek.com" target="_blank">embeetek.com</a>
        </footer>

        <script>
            function startStream() {
                const feed = document.getElementById('videoFeed');
                feed.src = '/video?' + Date.now();
                document.getElementById('liveText').innerText = 'LIVE';
                document.getElementById('liveDot').style.background = '#00c44f';
                document.getElementById('camDot').classList.remove('off');
                document.getElementById('camLabel').innerText = 'Camera';
            }

            function stopStream() {
                document.getElementById('videoFeed').src = '';
                document.getElementById('liveText').innerText = 'STOPPED';
                document.getElementById('liveDot').style.background = '#ff4444';
                document.getElementById('camDot').classList.add('off');
                document.getElementById('camLabel').innerText = 'Stopped';
            }
        </script>

    </body>
    </html>
    '''
# ── Drawing ───────────────────────────────────────────────────────────────────
def calc_bounding_rect(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]
    landmark_array = np.empty((0, 2), int)
    for _, landmark in enumerate(landmarks.landmark):
        lx = min(int(landmark.x * image_width), image_width - 1)
        ly = min(int(landmark.y * image_height), image_height - 1)
        landmark_array = np.append(landmark_array,
                                   [np.array((lx, ly))], axis=0)
    x, y, w, h = cv.boundingRect(landmark_array)
    return [x, y, x + w, y + h]


def calc_landmark_list(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]
    landmark_point = []
    for _, landmark in enumerate(landmarks.landmark):
        lx = min(int(landmark.x * image_width), image_width - 1)
        ly = min(int(landmark.y * image_height), image_height - 1)
        landmark_point.append([lx, ly])
    return landmark_point


def draw_landmarks(image, landmark_point):
    if len(landmark_point) > 0:
        connections = [
            (2,3),(3,4),(5,6),(6,7),(7,8),(9,10),(10,11),(11,12),
            (13,14),(14,15),(15,16),(17,18),(18,19),(19,20),
            (0,1),(1,2),(2,5),(5,9),(9,13),(13,17),(17,0)
        ]
        for a, b in connections:
            cv.line(image, tuple(landmark_point[a]),
                    tuple(landmark_point[b]), (0,0,0), 6)
            cv.line(image, tuple(landmark_point[a]),
                    tuple(landmark_point[b]), (255,255,255), 2)
        for idx, lm in enumerate(landmark_point):
            r = 8 if idx in [4,8,12,16,20] else 5
            cv.circle(image, (lm[0], lm[1]), r, (255,255,255), -1)
            cv.circle(image, (lm[0], lm[1]), r, (0,0,0), 1)
    return image


def draw_bounding_rect(use_brect, image, brect):
    if use_brect:
        cv.rectangle(image, (brect[0], brect[1]),
                     (brect[2], brect[3]), (0,0,0), 1)
    return image


def draw_info_text(image, brect, handedness, gesture):
    cv.rectangle(image, (brect[0], brect[1]),
                 (brect[2], brect[1]-22), (0,0,0), -1)
    info_text = handedness.classification[0].label + ':' + gesture
    cv.putText(image, info_text, (brect[0]+5, brect[1]-4),
               cv.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 1, cv.LINE_AA)

    h, w = image.shape[:2]
    overlay = image.copy()
    cv.rectangle(overlay, (0, h-90), (w, h), (0,0,0), -1)
    cv.addWeighted(overlay, 0.55, image, 0.45, 0, image)
    ts = cv.getTextSize(gesture, cv.FONT_HERSHEY_SIMPLEX, 2.0, 3)[0]
    tx = (w - ts[0]) // 2
    cv.putText(image, gesture, (tx, h-22),
               cv.FONT_HERSHEY_SIMPLEX, 2.0, (0,255,100), 3, cv.LINE_AA)
    return image


def draw_point_history(image, point_history):
    for index, point in enumerate(point_history):
        if point[0] != 0 and point[1] != 0:
            cv.circle(image, (point[0], point[1]),
                      1 + int(index/2), (152,251,152), 2)
    return image


def draw_fps(image, fps):
    cv.putText(image, "FPS:"+str(fps), (10,30),
               cv.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,0), 4, cv.LINE_AA)
    cv.putText(image, "FPS:"+str(fps), (10,30),
               cv.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 2, cv.LINE_AA)
    return image


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    global output_frame
    args = get_args()

    if args.stream_url:
        cap = cv.VideoCapture(args.stream_url)
        print(f"[INFO] Using stream: {args.stream_url}")
    else:
        cap = cv.VideoCapture(args.device)
        cap.set(cv.CAP_PROP_FRAME_WIDTH, args.width)
        cap.set(cv.CAP_PROP_FRAME_HEIGHT, args.height)
        print(f"[INFO] Using webcam: {args.device}")

    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=args.use_static_image_mode,
        max_num_hands=1,
        min_detection_confidence=args.min_detection_confidence,
        min_tracking_confidence=args.min_tracking_confidence,
    )

    # Start Flask in background thread
    flask_thread = threading.Thread(
        target=lambda: app.run(host='0.0.0.0', port=5000,
                               debug=False, use_reloader=False))
    flask_thread.daemon = True
    flask_thread.start()
    print("[INFO] Web server started at http://localhost:5000")

    cvFpsCalc = CvFpsCalc(buffer_len=10)
    point_history = deque(maxlen=16)
    last_published_gesture = ""

    while True:
        fps = cvFpsCalc.get()

        # cv.waitKey(1) — minimal block, keeps loop fast
        if cv.waitKey(1) == 27:
            break

        ret, image = cap.read()
        if not ret:
            if args.stream_url:
                print("[WARN] Stream lost. Reconnecting...")
                cap = cv.VideoCapture(args.stream_url)
                continue
            else:
                print("[ERROR] Webcam read failed.")
                break

        image = cv.flip(image, 1)
        debug_image = copy.deepcopy(image)

        rgb = cv.cvtColor(image, cv.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        results = hands.process(rgb)
        rgb.flags.writeable = True

        if results.multi_hand_landmarks is not None:
            for hand_landmarks, handedness in zip(
                    results.multi_hand_landmarks,
                    results.multi_handedness):

                brect = calc_bounding_rect(debug_image, hand_landmarks)
                landmark_list = calc_landmark_list(debug_image, hand_landmarks)
                gesture = classify_gesture(hand_landmarks.landmark)

                # Publish on gesture change
                if gesture != last_published_gesture and gesture != "Unknown":
                    try:
                        payload = json.dumps({"gesture": gesture})
                        mqtt_client.publish(TOPIC, payload)
                        print(f"[MQTT] Published: {gesture}")
                    except Exception as e:
                        print(f"[MQTT] Publish failed: {e}")
                    last_published_gesture = gesture

                if gesture == "I Have A Doubt":
                    point_history.append(landmark_list[8])
                else:
                    point_history.append([0, 0])

                debug_image = draw_bounding_rect(True, debug_image, brect)
                debug_image = draw_landmarks(debug_image, landmark_list)
                debug_image = draw_info_text(debug_image, brect,
                                             handedness, gesture)
        else:
            # Reset last gesture when hand leaves frame
            last_published_gesture = ""
            point_history.append([0, 0])

        debug_image = draw_point_history(debug_image, point_history)
        debug_image = draw_fps(debug_image, fps)

        # Update web stream frame
        with frame_lock:
            output_frame = debug_image.copy()

    cap.release()
    cv.destroyAllWindows()


if __name__ == '__main__':
    main()