@echo off
call conda activate gesture_env
python app.py --stream_url http://asl.local:81/stream
pause